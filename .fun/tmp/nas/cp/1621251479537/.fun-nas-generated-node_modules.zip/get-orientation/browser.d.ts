import { Orientation } from "./base";
export { Orientation };
export declare function getOrientation(input: ArrayBuffer | File | Blob): Promise<Orientation>;
