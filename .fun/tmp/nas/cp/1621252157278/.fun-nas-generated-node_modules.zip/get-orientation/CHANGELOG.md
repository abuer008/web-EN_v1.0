## [1.1.2](https://github.com/mooyoul/get-orientation/compare/v1.1.1...v1.1.2) (2019-10-01)


### Bug Fixes

* **release:** cleanup package contents ([22f32e1](https://github.com/mooyoul/get-orientation/commit/22f32e1))

## [1.1.1](https://github.com/mooyoul/get-orientation/compare/v1.1.0...v1.1.1) (2019-10-01)


### Bug Fixes

* **release:** bump version ([13e8392](https://github.com/mooyoul/get-orientation/commit/13e8392))

## 1.1.0

- Added ES5 target Browser build
- Added BrowserStack for testing compatibility


## 1.0.1

- Added type guard for non-typescript environment


## 1.0.0

- Fixed JPEG APP1 Marker Conflict issue
- Support Browser Environment


## 0.1.0

- Initial Release
