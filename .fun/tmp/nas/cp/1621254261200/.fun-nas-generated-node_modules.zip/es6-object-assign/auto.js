'use strict';

require('./index').polyfill();
