# `cssnano-preset-simple`

This is a small variant of `cssnano-preset-default` without `svgo` built-in.
